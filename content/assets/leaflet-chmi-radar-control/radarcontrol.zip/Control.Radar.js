'use strict';
L.Control.Radar = L.Control.extend({
	options: {
		position: 'topright',
		title: 'Srážkový radar',
		bounds: [[47.18233, 10.2407], [51.91764, 20.38871]],
		visible: true
	},

	initialize: function (options) 
	{
		L.Control.prototype.initialize.call(this, options);
		this._radarImages = this._loadRadarImages();
		this._image;
		this._map;
		this._interval = 0;
		this._radarIndex = 0;
	},

	onAdd: function(map) 
	{
		this._map = map;
		var className = 'leaflet-control-radar',
			that = this,
			container = this._container = L.DomUtil.create('div', className);

		L.DomEvent.disableClickPropagation(container);
		
		this._createButton(this.options.title, className, container, map);
		this._createTime(className, container, this.options.visible);

		/* If image should be visible, add it to the map */
		console.log(this.options.visible);
		if (this.options.visible) {
			var imageUrl 	= this._radarImages[0].src;
			this._image 	= L.imageOverlay(imageUrl, this.options.bounds);

			this._image.addTo(this._map);
			this._image.setOpacity(.4);
			this._interval = setInterval(function() {that._animateRadar();}, 1000);
		}

		return container;
	},

	/**
	 * Toggle radar animation.
	 */
	toggleRadar: function()
	{
		var that = this;

		if (this.options.visible) {
			this._image.setOpacity(0);
			clearTimeout(this._interval);
		} else {
			this._interval = setInterval(function() {that._animateRadar();}, 1000);
		}

		L.DomUtil.get(document.getElementsByClassName('leaflet-control-radar-time')[0]).style.display = !this.options.visible ? 'inline-block' : 'none'
		this.options.visible = !this.options.visible;
	},

	_animateRadar: function()
	{
		var url = this._radarImages[this._radarIndex].src;
		if (typeof this._image !== 'undefined') {
			this._image.setUrl(url);
		} else {
			this._image = L.imageOverlay(url, this.options.bounds);
			this._image.addTo(this._map);
		}
		this._image.setOpacity(0.4);

		this._radarIndex += 1;

		if (this._radarIndex === this._radarImages.length) {
			this._radarIndex = 0;
		}
		var time = L.DomUtil.get(document.getElementsByClassName('leaflet-control-radar-time')[0]);
		time.innerHTML = this._formatTime(url);
	},


	/**
	 * Format the date and time from image url into the human readable string.
	 * @param  {string} timestring image url containing date and time
	 * @return {string} formatted timestring
	 */
	_formatTime: function(timestring)
	{
		var temp      = timestring.split('.').slice(4,6),
			day       = temp[0].slice(-2),
			month     = temp[0].slice(-4,-2),
			hour      = parseInt(temp[1].slice(-4,-2)),
			minute    = temp[1].slice(-2);

		switch (hour) {
			case 22: hour = 0; break;
			case 23: hour = 1; break;
			default: hour += 2;
		}

		var time 	  = [day + '.', month + '.', '<br>', hour + ':', minute];

		for (var i = time.length - 1; i >= 0; i -= 1) {
			if (time[i].startsWith('0') && !time[i].endsWith('0')) {
				time[i] = time[i].slice(1);
			}
		}

		return time.join('')
	},

	/**
	 * Create toggle button for animation.
	 * @param string link title
	 * @param string className
	 * @param DOM node container
	 * @param Object context
	 */
	_createButton: function (title, className, container, context) 
	{
		var link = L.DomUtil.create('a', className + '-toggle', container);
		link.href = '#';
		link.title = this.options.title;

		L.DomEvent.addListener(link, 'click', this.toggleRadar, this);

		return link;
	},

	/**
	 * Create span container for time and date of an image.
	 * @param {string} className
	 * @param {HTMLElement} container
	 * @param {boolean} display should be the span visible
	 */
	_createTime: function(className, container, display)
	{
		var text = L.DomUtil.create('span', className + '-time', container);
		text.style.display = display ? 'inline-block' : 'none';
		return text;
	},

	_loadRadarImages: function()
	{
		var time         = new Date()
			,year        = time.getFullYear()
			,month       = time.getMonth() /* 0-11 */
			,day         = time.getUTCDate() /* 1-31 */
			,hour        = time.getUTCHours() - Math.abs(time.getTimezoneOffset() / 60)  /* 0-23 */
			,minute      = time.getMinutes()
			,radarImages = []
			,i = 0
			,tempMonth   = new String(month+1).length === 1 ? "0" + (month + 1) : month + 1
			,tempDay     = new String(day+1).length === 1 ? "0" + (day) : day
			,quarter;

		if (minute < 15) {
			quarter = 0;
		} else if (minute < 30) {
			quarter = 15;
		} else if (minute < 45) {
			quarter = 30;
		} else {
			quarter = 45;
		}

		var tempQuarter = quarter.toString().length === 1 ? "0" + quarter : quarter
			,url		= 'http://radar.bourky.cz/data/pacz2gmaps.z_max3d.' + year + tempMonth + tempDay + '.' + hour + tempQuarter + '.0.png';
		
		for (i; i < 15; i += 1) {
			if (quarter === 0) {
				quarter = 45;
				hour = (hour - 1) < 0 ? 23 : hour - 1;				
			} else {
				quarter -= 15;
			}

			if (hour === 23 && quarter === 45) {
				if (!(day - 1 <= 0)) {
					day -= 1;
				} else {
					month = month === 0 ? 11 : month - 1;
					day = time.monthDays(year, month);
				}
			}
			
			if (month === 11 && day === 31 && hour === 23 && quarter === 45) {
				year -= 1;
			}
			var tempMonth    = (month+1).toString().length === 1 ? "0" + (month + 1) : month+1
				,tempDay     = day.toString().length === 1 ? "0" + day : day
				,tempHour    = hour.toString().length === 1 ? "0" + hour : hour
				,tempQuarter = quarter.toString().length === 1 ? "0" + quarter : quarter
				,newURL      = 'http://radar.bourky.cz/data/pacz2gmaps.z_max3d.' + year + tempMonth + tempDay + '.' + tempHour + tempQuarter + '.0.png'
				,img         = new Image();

			img.src          = newURL;
			radarImages.unshift(img);
		}
		return radarImages;
	}
})

if (!String.prototype.startsWith) {
  Object.defineProperty(String.prototype, 'startsWith', {
    enumerable: false,
    configurable: false,
    writable: false,
    value: function (searchString, position) {
      position = position || 0;
      return this.indexOf(searchString, position) === position;
    }
  });
}

if (!String.prototype.endsWith) {
    Object.defineProperty(String.prototype, 'endsWith', {
        enumerable: false,
        configurable: false,
        writable: false,
        value: function (searchString, position) {
            position = position || this.length;
            position = position - searchString.length;
            var lastIndex = this.lastIndexOf(searchString);
            return lastIndex !== -1 && lastIndex === position;
        }
    });
}